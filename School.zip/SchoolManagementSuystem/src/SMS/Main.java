package SMS;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;
public class Main {

	public static void main(String[] args) {
		System.out.println("Welcome to School management System");
		Scanner sc=new Scanner(System.in); 
		int User=12345;
		int pass=123;
		System.out.println("Enter the User name:");
		int u=sc.nextInt();
		System.out.println("Enter the Password:");
		int p=sc.nextInt();
		Student s1 = new Student(1,"Savitha",10);
		Student s2 = new Student(2,"Narmtha",11);
		Student s3 = new Student(3,"Vimal",12);

		List<Student> studentList = new ArrayList<>();
		studentList.add(s1);
		studentList.add(s2);
		studentList.add(s3);
		Teacher t1 = new Teacher(1,"Nivetha",1000);
		Teacher t2 = new Teacher(2,"Lokesh",700);
		Teacher t3 = new Teacher(3,"Abi",800);

			List<Teacher> teacherList = new ArrayList<>();
			teacherList.add(t1);
			teacherList.add(t2);
			teacherList.add(t3);
School s = new School(teacherList, studentList);
			Teacher t4 = new Teacher(4,"Kiran Bhatt",600);
			s.addTeacher(t4);
			Student s4=new Student(4,"Akash Jain",11);
			s.addStudent(s4);
	//pay fees
			s1.payFees(5000);
			s2.payFees(6000);
			s3.payFees(30000);
	s4.payFees(10000);
	
	if((User==u) && (pass==p)) 
	{
while(true)
{
	System.out.println("1.Student Details\n2.Teacher Details\n3.MoneyEarned\n4.MoneySpent\n5.Exit");
	System.out.println("Enter the Choice");
	int ch=sc.nextInt();	
		if(ch==1)
		{
			System.out.println("------------------Student Details---------------");
			for(Student st:studentList) {
				System.out.println(st);
			}
		}
		else if(ch==2)
		{
			System.out.println("-----------------------Teacher Details-------------------------------------");
			for(Teacher te:teacherList) {
				System.out.println(te);
			}
		}
			else if(ch==3)
			{
				System.out.println("-----\t\tSCHOOL FUND EARNED: $" + s.getTotalMoneyEarned()+"\t\t-----");
			}
			else if(ch==4)
			{
				System.out.println("-----\t\tSCHOOL PAYS SALARY TO TEACHER\t\t\t\t-----");
				for(Teacher t:teacherList){
					t.receiveSalary(t.getSalary());
					System.out.println("MONEY SPENT SALARY TO: " + t.getName()+" "+"Salary is :"+t.getSalary()+" "+ "|| TOTAL MONEY AFTER SALARY: "+ s.getTotalMoneyEarned());
					
				}}
				else if(ch==5)
				{
					System.out.println("Thank You");	
				}
				
			else
			{
				
				System.out.println("Please give coreect choice ");
	}
			
		
}
	}	
	else
	{
		System.out.println("please enter the correect username and password");
	}
		}
			
	}

