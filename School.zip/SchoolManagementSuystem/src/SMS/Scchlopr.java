package SMS;

public interface Scchlopr {
public void viewStudent();
public void viewteacher();
public void moneyearned();
public void moneyspent();
}
